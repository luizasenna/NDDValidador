<?php

namespace InfyOm\Generator\Contracts;

interface TemplatesPublisherContract
{
    public function publish();
}
