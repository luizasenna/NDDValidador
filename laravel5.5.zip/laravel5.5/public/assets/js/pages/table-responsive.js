$("table").DataTable({
    responsive:true
});
