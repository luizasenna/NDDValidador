<?php
/**
* Language file for general strings
*
*/
return array(
    'no'  			=> 'Nein',
    'noresults'  	=> 'Keine Ergebnisse',
    'yes' 			=> 'Ja',
    'site_name'     => 'Seiten Name'
);
