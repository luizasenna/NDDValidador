<?php
/**
* Language file for general strings
*
*/
return array(

    'no'  			=> 'No',
    'noresults'  	=> 'No Results',
    'yes' 			=> 'Yes',
    'site_name' => 'SiteName',
    'home' => 'Home',
    'dashboard' => 'Dashboard',

);
